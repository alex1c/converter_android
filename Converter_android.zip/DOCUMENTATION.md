# Полная документация проекта "Универсальный конвертер"

## 📋 Содержание

1. [Обзор проекта](#обзор-проекта)
2. [Архитектура](#архитектура)
3. [Текущее состояние](#текущее-состояние)
4. [Структура проекта](#структура-проекта)
5. [Технологии и зависимости](#технологии-и-зависимости)
6. [Реализованные функции](#реализованные-функции)
7. [Планы развития](#планы-развития)
8. [Инструкции по расширению](#инструкции-по-расширению)
9. [Сборка и запуск](#сборка-и-запуск)

---

## 🎯 Обзор проекта

**Универсальный конвертер** — Android-приложение для конвертации различных физических величин между единицами измерения.

### Основные характеристики

- ✅ **Автономное приложение** — работает без серверов, все данные хранятся локально
- ✅ **Clean Architecture + MVVM** — модульная, расширяемая архитектура
- ✅ **Jetpack Compose** — современный декларативный UI
- ✅ **Material Design 3** — актуальный дизайн
- ✅ **Локализация** — поддержка русского и английского языков
- ✅ **Готовность к публикации** — соответствует требованиям RuStore

### Версия

**v1.0** — Базовая версия с поддержкой конвертации веса, длины и объёма

---

## 🏗️ Архитектура

### Принципы архитектуры

Проект построен на основе **Clean Architecture** с применением паттерна **MVVM**:

```
┌─────────────────────────────────────────┐
│         Presentation Layer              │
│  (UI, Navigation, Categories Screen)   │
└─────────────────────────────────────────┘
                  │
┌─────────────────────────────────────────┐
│            UI Layer                     │
│  (Screens, ViewModels, State)          │
└─────────────────────────────────────────┘
                  │
┌─────────────────────────────────────────┐
│           Data Layer                    │
│  (Converters, Units Data)               │
└─────────────────────────────────────────┘
                  │
┌─────────────────────────────────────────┐
│          Domain Layer                   │
│  (Models, Use Cases, Business Logic)    │
└─────────────────────────────────────────┘
                  │
┌─────────────────────────────────────────┐
│            Core Layer                   │
│  (Interfaces, Utils, Constants)         │
└─────────────────────────────────────────┘
```

### Слои архитектуры

#### 1. Core Layer
**Назначение:** Базовые интерфейсы и утилиты, используемые во всём приложении

**Компоненты:**
- `UnitConverter<T>` — универсальный интерфейс для всех конвертеров
- `Constants` — константы приложения

**Особенности:**
- Независим от других слоёв
- Не содержит зависимостей от Android-фреймворков
- Легко тестируется

#### 2. Domain Layer
**Назначение:** Бизнес-логика и модели данных

**Компоненты для каждой категории:**
- `[Category]Unit` — enum с единицами измерения и коэффициентами
- `Convert[Category]UseCase` — use case для конвертации

**Особенности:**
- Чистая бизнес-логика без зависимостей от UI
- Реализует универсальный интерфейс `UnitConverter<T>`
- Все конвертации через базовую единицу

#### 3. Data Layer
**Назначение:** Доступ к данным и обёртки для domain-слоя

**Компоненты для каждой категории:**
- `[Category]Units` — объект для доступа к единицам измерения
- `[Category]Converter` — обёртка конвертера для data-слоя

**Особенности:**
- Простые обёртки над domain-слоем
- Предоставляет удобный API для UI-слоя

#### 4. UI Layer
**Назначение:** Пользовательский интерфейс и управление состоянием

**Компоненты для каждой категории:**
- `[Category]ViewModel` — управление состоянием экрана
- `[Category]Screen` — Compose UI экран
- `[Category]UiState` — data class для состояния UI

**Особенности:**
- Реактивное управление состоянием через StateFlow
- Единый стиль UI для всех категорий
- Анимации и плавные переходы

#### 5. Presentation Layer
**Назначение:** Навигация, главный экран категорий, тема

**Компоненты:**
- `MainActivity` — главная активность
- `NavGraph` — граф навигации
- `CategoriesScreen` — экран выбора категорий
- `ConverterCategory` — модель категории
- `Theme` — тема приложения (Material3)

---

## 📊 Текущее состояние

### Реализованные категории конвертации

#### ✅ 1. Вес (Weight)
**Статус:** Полностью реализовано

**Единицы измерения (6):**
- Килограмм (базовая единица)
- Грамм
- Тонна
- Фунт
- Унция
- Миллиграмм

**Файлы:**
- `features/weight/domain/models/WeightUnit.kt`
- `features/weight/domain/convert_weight_usecase.kt`
- `features/weight/data/WeightUnits.kt`
- `features/weight/data/WeightConverter.kt`
- `features/weight/ui/WeightViewModel.kt`
- `features/weight/ui/WeightScreen.kt`

#### ✅ 2. Длина (Length)
**Статус:** Полностью реализовано

**Единицы измерения (9):**
- Метр (базовая единица)
- Километр
- Сантиметр
- Миллиметр
- Миля
- Ярд
- Фут
- Дюйм
- Морская миля

**Файлы:**
- `features/length/domain/models/LengthUnit.kt`
- `features/length/domain/convert_length_usecase.kt`
- `features/length/data/LengthUnits.kt`
- `features/length/data/LengthConverter.kt`
- `features/length/ui/LengthViewModel.kt`
- `features/length/ui/LengthScreen.kt`

#### ✅ 3. Объём (Volume)
**Статус:** Полностью реализовано

**Единицы измерения (10):**
- Литр (базовая единица)
- Миллилитр
- Кубический метр
- Кубический сантиметр
- Галлон (US)
- Галлон (UK)
- Пинта
- Чашка (cup)
- Столовая ложка (tbsp)
- Чайная ложка (tsp)

**Файлы:**
- `features/volume/domain/models/VolumeUnit.kt`
- `features/volume/domain/convert_volume_usecase.kt`
- `features/volume/data/VolumeUnits.kt`
- `features/volume/data/VolumeConverter.kt`
- `features/volume/ui/VolumeViewModel.kt`
- `features/volume/ui/VolumeScreen.kt`

### Главный экран категорий

**Статус:** Полностью реализовано

**Функциональность:**
- Сетка категорий (2 колонки)
- Карточки с иконками и названиями
- Навигация к экранам конвертации
- Material Design 3 стиль

**Файлы:**
- `presentation/categories/CategoriesScreen.kt`
- `presentation/categories/CategoriesData.kt`
- `presentation/categories/ConverterCategory.kt`

### Навигация

**Статус:** Полностью реализовано

**Маршруты:**
- `/categories` — главный экран (стартовый)
- `/weight` — конвертер веса
- `/length` — конвертер длины
- `/volume` — конвертер объёма

**Файлы:**
- `presentation/navigation/NavGraph.kt`

### Локализация

**Статус:** Полностью реализовано

**Поддерживаемые языки:**
- Русский (по умолчанию)
- Английский

**Файлы:**
- `res/values/strings.xml` (русский)
- `res/values-ru/strings.xml` (русский, дубликат для совместимости)

---

## 📁 Структура проекта

```
app/
├── src/main/
│   ├── java/com/example/converter_android/
│   │   ├── core/                          # Общие компоненты
│   │   │   ├── converters/
│   │   │   │   └── UnitConverter.kt       # Универсальный интерфейс
│   │   │   └── utils/
│   │   │       └── Constants.kt          # Константы
│   │   │
│   │   ├── features/                      # Модули функций
│   │   │   ├── weight/                    # Конвертер веса
│   │   │   │   ├── data/
│   │   │   │   │   ├── WeightUnits.kt
│   │   │   │   │   └── WeightConverter.kt
│   │   │   │   ├── domain/
│   │   │   │   │   ├── models/
│   │   │   │   │   │   └── WeightUnit.kt
│   │   │   │   │   └── convert_weight_usecase.kt
│   │   │   │   └── ui/
│   │   │   │       ├── WeightScreen.kt
│   │   │   │       └── WeightViewModel.kt
│   │   │   │
│   │   │   ├── length/                    # Конвертер длины
│   │   │   │   ├── data/
│   │   │   │   │   ├── LengthUnits.kt
│   │   │   │   │   └── LengthConverter.kt
│   │   │   │   ├── domain/
│   │   │   │   │   ├── models/
│   │   │   │   │   │   └── LengthUnit.kt
│   │   │   │   │   └── convert_length_usecase.kt
│   │   │   │   └── ui/
│   │   │   │       ├── LengthScreen.kt
│   │   │   │       └── LengthViewModel.kt
│   │   │   │
│   │   │   └── volume/                    # Конвертер объёма
│   │   │       ├── data/
│   │   │       │   ├── VolumeUnits.kt
│   │   │       │   └── VolumeConverter.kt
│   │   │       ├── domain/
│   │   │       │   ├── models/
│   │   │       │   │   └── VolumeUnit.kt
│   │   │       │   └── convert_volume_usecase.kt
│   │   │       └── ui/
│   │   │           ├── VolumeScreen.kt
│   │   │           └── VolumeViewModel.kt
│   │   │
│   │   └── presentation/                  # Презентационный слой
│   │       ├── MainActivity.kt            # Главная активность
│   │       ├── categories/                # Главный экран категорий
│   │       │   ├── CategoriesScreen.kt
│   │       │   ├── CategoriesData.kt
│   │       │   └── ConverterCategory.kt
│   │       ├── navigation/
│   │       │   └── NavGraph.kt           # Граф навигации
│   │       └── theme/                     # Тема приложения
│   │           ├── Color.kt
│   │           ├── Theme.kt
│   │           └── Type.kt
│   │
│   └── res/
│       ├── values/
│       │   └── strings.xml               # Русские строки (по умолчанию)
│       └── values-ru/
│           └── strings.xml               # Русские строки
│
├── build.gradle.kts                      # Конфигурация модуля
└── proguard-rules.pro                    # Правила ProGuard
```

---

## 🛠️ Технологии и зависимости

### Язык программирования
- **Kotlin 2.0.21**

### Основные библиотеки

#### Android SDK
- **compileSdk:** 36
- **minSdk:** 24
- **targetSdk:** 36

#### Jetpack Compose
- **Compose BOM:** 2024.12.01
- **Material3**
- **Activity Compose:** 1.9.3
- **Navigation Compose:** 2.8.4

#### Lifecycle
- **Lifecycle Runtime KTX:** 2.8.6
- **Lifecycle ViewModel Compose:** 2.8.6

#### Другие
- **Material Icons Extended** — для расширенного набора иконок

### Конфигурация

**Gradle:** Version Catalog (libs.versions.toml)

**Kotlin Compiler Extension:** 1.5.14

---

## ✨ Реализованные функции

### Функциональность

#### 1. Главный экран категорий
- ✅ Отображение всех доступных категорий конвертации
- ✅ Сетка карточек (2 колонки)
- ✅ Иконки для каждой категории
- ✅ Навигация к экранам конвертации

#### 2. Экран конвертации (для каждой категории)
- ✅ Поле ввода значения
- ✅ Выпадающий список "Из единицы"
- ✅ Выпадающий список "В единицу"
- ✅ Кнопка "Поменять местами"
- ✅ Блок результата с анимацией
- ✅ Автоматический пересчёт при изменении
- ✅ Кнопка "Назад" для возврата к категориям

#### 3. Конвертация
- ✅ Конвертация через базовую единицу
- ✅ Поддержка всех единиц измерения категории
- ✅ Точность до 6 знаков после запятой
- ✅ Автоматическое удаление лишних нулей

#### 4. UI/UX
- ✅ Material Design 3
- ✅ Плавные анимации результата
- ✅ Адаптивный дизайн
- ✅ Поддержка светлой темы
- ✅ Локализация (русский/английский)

### Технические особенности

#### Архитектура
- ✅ Clean Architecture с разделением на слои
- ✅ MVVM паттерн
- ✅ Универсальный интерфейс `UnitConverter<T>`
- ✅ Модульная структура (каждая категория — отдельный модуль)

#### Код
- ✅ Чистый, читаемый код
- ✅ Подробные комментарии на английском
- ✅ Следование best practices
- ✅ Отсутствие захардкоженных строк
- ✅ Все константы в одном месте

---

## 🚀 Планы развития

### Краткосрочные планы (v1.1 - v1.3)

#### v1.1 — Температура
**Приоритет:** Высокий

**Единицы измерения:**
- Цельсий (°C)
- Фаренгейт (°F)
- Кельвин (K)

**Особенности:**
- Специальная логика конвертации (не через базовую единицу)
- Возможность расширения на Ранкин, Реомюр

#### v1.2 — Площадь
**Приоритет:** Средний

**Единицы измерения:**
- Квадратный метр (м²)
- Квадратный километр (км²)
- Гектар
- Акр
- Квадратная миля
- Квадратный фут
- Квадратный дюйм

#### v1.3 — Скорость
**Приоритет:** Средний

**Единицы измерения:**
- Метр в секунду (м/с)
- Километр в час (км/ч)
- Миля в час (миль/ч)
- Узел (морская миля/час)
- Фут в секунду

### Среднесрочные планы (v2.0 - v2.5)

#### v2.0 — Время
**Приоритет:** Низкий

**Единицы измерения:**
- Секунда
- Минута
- Час
- День
- Неделя
- Месяц
- Год

#### v2.1 — Энергия
**Приоритет:** Низкий

**Единицы измерения:**
- Джоуль
- Килоджоуль
- Калория
- Килокалория
- Ватт-час
- Киловатт-час

#### v2.2 — Давление
**Приоритет:** Низкий

**Единицы измерения:**
- Паскаль
- Килопаскаль
- Бар
- Атмосфера
- Миллиметр ртутного столба
- Фунт на квадратный дюйм (PSI)

#### v2.3 — Масса/Вес (расширение)
**Приоритет:** Низкий

**Дополнительные единицы:**
- Карат
- Стоун
- Тройская унция

#### v2.4 — Улучшения UI
**Приоритет:** Средний

**Функции:**
- История конвертаций
- Избранные единицы
- Быстрый доступ к часто используемым конвертациям
- Темная тема
- Настройки приложения

#### v2.5 — Дополнительные функции
**Приоритет:** Низкий

**Функции:**
- Экспорт результатов
- Виджет для главного экрана
- Голосовой ввод
- Калькулятор с конвертацией

### Долгосрочные планы (v3.0+)

#### v3.0 — Расширенная функциональность
- Множественные конвертации одновременно
- Графики и визуализация
- Офлайн справочник единиц измерения
- Интеграция с другими приложениями

#### v3.1 — Социальные функции
- Обмен конвертациями
- Рейтинг единиц измерения
- Комментарии и обсуждения

---

## 📖 Инструкции по расширению

### Как добавить новую категорию конвертации

#### Шаг 1: Создать domain слой

**1.1. Создать enum единиц измерения**

Создайте файл: `features/[category]/domain/models/[Category]Unit.kt`

```kotlin
package com.example.converter_android.features.temperature.domain.models

enum class TemperatureUnit(
    val displayNameRes: Int,
    val conversionFactorToBase: Double
) {
    CELSIUS(R.string.unit_celsius, 1.0),
    FAHRENHEIT(R.string.unit_fahrenheit, 1.0),
    KELVIN(R.string.unit_kelvin, 1.0)
}
```

**Примечание:** Для температуры нужна специальная логика, так как это не линейная конвертация.

**1.2. Создать use case**

Создайте файл: `features/[category]/domain/convert_[category]_usecase.kt`

```kotlin
package com.example.converter_android.features.temperature.domain

import com.example.converter_android.core.converters.UnitConverter
import com.example.converter_android.features.temperature.domain.models.TemperatureUnit

class ConvertTemperatureUseCase : UnitConverter<TemperatureUnit> {
    override fun convert(value: Double, from: TemperatureUnit, to: TemperatureUnit): Double {
        if (from == to) return value
        
        // Специальная логика для температуры
        val celsius = when (from) {
            TemperatureUnit.CELSIUS -> value
            TemperatureUnit.FAHRENHEIT -> (value - 32) * 5 / 9
            TemperatureUnit.KELVIN -> value - 273.15
        }
        
        return when (to) {
            TemperatureUnit.CELSIUS -> celsius
            TemperatureUnit.FAHRENHEIT -> celsius * 9 / 5 + 32
            TemperatureUnit.KELVIN -> celsius + 273.15
        }
    }
}
```

#### Шаг 2: Создать data слой

**2.1. Создать [Category]Units.kt**

```kotlin
package com.example.converter_android.features.temperature.data

import com.example.converter_android.features.temperature.domain.models.TemperatureUnit

object TemperatureUnits {
    fun getAllUnits(): List<TemperatureUnit> = TemperatureUnit.values().toList()
    fun getDefaultFromUnit(): TemperatureUnit = TemperatureUnit.CELSIUS
    fun getDefaultToUnit(): TemperatureUnit = TemperatureUnit.FAHRENHEIT
}
```

**2.2. Создать [Category]Converter.kt**

```kotlin
package com.example.converter_android.features.temperature.data

import com.example.converter_android.features.temperature.domain.ConvertTemperatureUseCase
import com.example.converter_android.features.temperature.domain.models.TemperatureUnit

class TemperatureConverter {
    private val convertTemperatureUseCase = ConvertTemperatureUseCase()
    
    fun convert(value: Double, from: TemperatureUnit, to: TemperatureUnit): Double {
        return convertTemperatureUseCase.convert(value, from, to)
    }
}
```

#### Шаг 3: Создать UI слой

**3.1. Создать [Category]ViewModel.kt**

Скопируйте структуру из `LengthViewModel.kt` и замените:
- `Length` → `[Category]`
- `LengthUnit` → `[Category]Unit`
- `LengthConverter` → `[Category]Converter`
- `LengthUnits` → `[Category]Units`

**3.2. Создать [Category]Screen.kt**

Скопируйте структуру из `LengthScreen.kt` и замените:
- `Length` → `[Category]`
- `LengthUnit` → `[Category]Unit`
- `LengthViewModel` → `[Category]ViewModel`
- Заголовок экрана

#### Шаг 4: Добавить в навигацию

**4.1. Обновить NavGraph.kt**

```kotlin
// Добавить импорт
import com.example.converter_android.features.temperature.ui.TemperatureScreen
import com.example.converter_android.features.temperature.ui.TemperatureViewModel

// Добавить в when
"temperature" -> navController.navigate(Screen.Temperature.route)

// Добавить composable
composable(route = Screen.Temperature.route) {
    val temperatureViewModel: TemperatureViewModel = viewModel()
    TemperatureScreen(
        viewModel = temperatureViewModel,
        onBackClick = { navController.popBackStack() }
    )
}

// Добавить в sealed class Screen
object Temperature : Screen("temperature")
```

**4.2. Обновить CategoriesData.kt**

```kotlin
ConverterCategory(
    id = "temperature",
    title = "Температура",
    icon = Icons.Default.Thermostat
)
```

#### Шаг 5: Добавить локализацию

**5.1. Обновить strings.xml**

```xml
<!-- Temperature Converter -->
<string name="temperature_converter_title">Конвертер температуры</string>

<!-- Temperature Units -->
<string name="unit_celsius">Цельсий</string>
<string name="unit_fahrenheit">Фаренгейт</string>
<string name="unit_kelvin">Кельвин</string>
```

### Шаблон для новой категории

Для быстрого создания новой категории можно использовать следующий шаблон:

1. Скопировать структуру папок из существующей категории (например, `length`)
2. Заменить все упоминания `Length` на название новой категории
3. Обновить enum с единицами измерения
4. Обновить коэффициенты конвертации
5. Добавить в навигацию и CategoriesData
6. Добавить строки локализации

---

## 🔧 Сборка и запуск

### Требования

- **Android Studio:** Hedgehog или новее
- **JDK:** 11 или выше
- **Android SDK:** 24+ (минимум), 36 (target)
- **Gradle:** 8.13.1

### Сборка проекта

#### Через Android Studio

1. Откройте проект в Android Studio
2. Дождитесь синхронизации Gradle
3. Нажмите **Run** (Shift+F10) или выберите **Build → Make Project**

#### Через командную строку

```bash
# Windows
.\gradlew.bat assembleDebug

# Linux/Mac
./gradlew assembleDebug
```

### Установка APK

После сборки APK будет находиться в:
```
app/build/outputs/apk/debug/app-debug.apk
```

Установка на устройство:
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

### Тестирование

#### Unit тесты
```bash
./gradlew test
```

#### Инструментальные тесты
```bash
./gradlew connectedAndroidTest
```

---

## 📝 Примечания по реализации

### Конвертация через базовую единицу

Все категории (кроме температуры) используют единый подход:
1. Выбрать базовую единицу (метрическая)
2. Все единицы имеют коэффициент относительно базовой
3. Конвертация: `value → базовая единица → целевая единица`

**Пример:**
```kotlin
// Вес: базовая единица — килограмм
val valueInKg = value * from.conversionFactorToKg
val result = valueInKg / to.conversionFactorToKg
```

### Специальные случаи

**Температура:** Требует специальной логики, так как это не линейная конвертация. Все температуры конвертируются через Цельсий.

### UI компоненты

Все экраны конвертации используют единый компонент `UnitDropdown` для выбора единиц. Это обеспечивает:
- Единообразный UI
- Простоту поддержки
- Легкость изменений

### Навигация

Навигация построена на Navigation Component для Compose. Все маршруты определены в sealed class `Screen`, что обеспечивает:
- Типобезопасность
- Легкость добавления новых экранов
- Централизованное управление маршрутами

---

## 🐛 Известные проблемы и ограничения

### Текущие ограничения

1. **DropdownMenu позиционирование:** Используется упрощённый вариант с `Box` вместо `ExposedDropdownMenuBox` из-за проблем с доступностью в текущей версии Material3

2. **Темная тема:** Пока не реализована (планируется в v2.4)

3. **История конвертаций:** Не сохраняется между сессиями (планируется в v2.4)

### Потенциальные улучшения

1. Добавить валидацию ввода (ограничение на отрицательные значения для некоторых единиц)
2. Добавить поддержку научной нотации
3. Улучшить обработку очень больших/маленьких чисел
4. Добавить возможность копирования результата

---

## 📚 Дополнительные ресурсы

### Документация

- `README.md` — основная документация проекта
- `EXPANSION_GUIDE.md` — подробное руководство по расширению
- `PROJECT_SUMMARY.md` — краткая сводка проекта

### Полезные ссылки

- [Jetpack Compose Documentation](https://developer.android.com/jetpack/compose)
- [Material Design 3](https://m3.material.io/)
- [Navigation Component](https://developer.android.com/guide/navigation)
- [Clean Architecture](https://developer.android.com/topic/architecture)

---

## 📊 Статистика проекта

### Код

- **Язык:** Kotlin 100%
- **Архитектура:** Clean Architecture + MVVM
- **UI Framework:** Jetpack Compose
- **Минимальный SDK:** 24 (Android 7.0)
- **Target SDK:** 36 (Android 14+)

### Реализовано

- **Категорий конвертации:** 3
- **Всего единиц измерения:** 25
  - Вес: 6 единиц
  - Длина: 9 единиц
  - Объём: 10 единиц
- **Экранов:** 4 (главный + 3 конвертера)
- **Языков локализации:** 2 (русский, английский)

### Планируется

- **Категорий в разработке:** 7+
- **Дополнительных функций:** 10+

---

## 🎯 Цели проекта

### Краткосрочные (3-6 месяцев)

1. ✅ Реализовать базовые категории (вес, длина, объём)
2. ⏳ Добавить температуру и площадь
3. ⏳ Улучшить UI/UX
4. ⏳ Добавить темную тему

### Среднесрочные (6-12 месяцев)

1. ⏳ Реализовать все основные категории конвертации
2. ⏳ Добавить историю конвертаций
3. ⏳ Добавить настройки приложения
4. ⏳ Публикация в RuStore

### Долгосрочные (12+ месяцев)

1. ⏳ Расширенная функциональность
2. ⏳ Социальные функции
3. ⏳ Интеграция с другими сервисами
4. ⏳ Версия для других платформ (iOS, Web)

---

## 👥 Участие в разработке

### Как внести вклад

1. Создать issue с описанием проблемы/предложения
2. Форкнуть репозиторий
3. Создать feature branch
4. Внести изменения
5. Создать Pull Request

### Стандарты кода

- Следовать правилам из `user_rules`
- Писать комментарии на английском
- Использовать Clean Architecture
- Покрывать код тестами
- Обновлять документацию

---

**Версия документации:** 1.0  
**Последнее обновление:** 2024  
**Статус проекта:** В активной разработке

